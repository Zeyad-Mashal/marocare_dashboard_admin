const brandEn = [
  "Afle",
  "La Roche posay",
  "Agrado",
  "Close up",
  "Air Queen",

  "Anjou",

  "Baby Zone",

  "Beauty Star",

  "Bioderma",

  "Bio-Oil",

  "Bixdent",

  "Black",

  "Bourjois",

  "Cantu",

  "Carefree",

  "CeraVe",

  "Clean & Clear",

  "Clear",

  "Clere",

  "Cotton Plus",

  "Cream 21",

  "Depend",

  "Diva",

  "Dorco",

  "Dr. Rashel",

  "E.l.f ",

  "Essence",

  "Eucerin",

  "Flexitol",

  "Garden Olean ",

  "Garnier",

  "Giovanni",

  "Glycerin",

  "Hair System",

  "Hansaplast",

  "Himalaya",

  "Hobelabs",

  "Ikeratin",

  "Isdin",

  "Johnson",

  "L`Oreal",

  "Labello",

  "Leivy",

  "Life-Flo",

  "Listerine",

  "Make Over 22",

  "Mandy",

  "Mac",

  "Maybelline",

  "Missha",

  "Moodmatcher",

  "Nature's Answer",

  "Neutrogena",

  "Nivea",

  "Nu-Pore",

  "Ofra",

  "Ogx",

  "O'keeffe's",

  "Olaplex",

  "Ordinary",

  "Palmer's",

  "Pixi",

  "Professional",

  "Qv",

  "Revolution",

  "Sairo",

  "Sebamed",

  "Shifa",

  "Shimmer",

  "Shimmer Lights",

  "Silky",

  "Silky Cool",

  "Spa System",

  "Titania",
  "Tony Moly",
  "Trind",
  "Yorx",
  "Mane n tail",
  "Safeeza",
  "Flamingo",
  "Almontaj",
  "Gluta-c",
  "Jessica",
  "Natured",
  "Mavala",
  "Queen view",
  "Lipo base",
  "Sense of Argan",
  "Hammam el hana",
  "Voloria",
  "Tesori d' oriente",
  "Estelin",
  "Yc",
  "X8 body hardware",
  "Pantene",
  "Vichy",
  "Shea moisture",
  "Bigen",
  "Eco tools",
  "Ear sense",
  "Wadi Al nahil",
  "Revlon",
  "Munchkin",
  "Reverse",
  "Purederm",
  "Gillette",
  "Real techniques",
  "I'm sorry",
  "Carissa",
  "Konoz",
  "Parodontax",
  "Paw patrol",
  "Dettol",
  "Always",
  "L.A girl",
  "Dove",
  "Arm & hammer",
  "Amwaj",
  "Italus",
  "Silk surgical",
  "Rexona",
  "Fresh me",
  "Shams",
  "Head & shoulders",
  "Parachute",
  "Mustela",
  "Uriage",
  "Crest",
  "Sensodyne",
  "Avalon",
  "Timeless",
  "Lens me",
  "Aloedent",
  "Sani plast",
  "Lakme",
  "Benefit",
  "Oral B",
  "Carrot sun",
  "Summer's eve",
  "J-castal",
  "Wella",
  "Al Arayes",
  "Schick intuition",
  "Colgate",
  "Cute",
  "Global star",
  "Signal",
  "Laikou",
  "TECE",
  "OZ Naturals",
  "Missha",
  "Vaseline",
];
export default brandEn;
